# SYNCHRONIZATION

Create a circular buffer of given size, and a number of producer and consumer threads utlizing it concurrently.

## Build

    make

## Run

    ./main <buffer size> <number of producers> <number of consumers> 

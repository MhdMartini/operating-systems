#ifndef MAINFUNC_H
#define MAINFUNC_H

std::string getCmd(int cNum, int numExecs = 5);
#endif
# MULTIPROCESSING

Create a user-specified number of processes to run the executables (test1 - test5).

## Build

    make

## Run

    ./main $N

# HW2

## Description

1. **main1**: Parent creates child thread and waits for it to fininsh.
2. **main2**:  Two threads have to 'meet' at some point in the code before proceeding.
3. **main3**: N threads (user specified) have to 'meet' before proceeding.

### Build

    make

### Run

    ./main1
    ./main2
    ./main3 <number of threads>
